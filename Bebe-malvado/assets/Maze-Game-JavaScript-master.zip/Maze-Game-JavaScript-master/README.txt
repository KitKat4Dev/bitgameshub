Referrences

Existing original game - https://html5.litten.com/make-a-maze-game-on-an-html5-canvas/
Maze GIF Creator - http://hereandabove.com/maze/mazeorig.form.html
Timer - https://stackoverflow.com/a/5517836
