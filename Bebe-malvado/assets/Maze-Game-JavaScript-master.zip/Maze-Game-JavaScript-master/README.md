# Labyrinthus - A Maze Game [PLAY NOW](https://husseinaltaaf.github.io/labyrinthus_javascript_game/)

This is simply a Maze game where you have to start from one point and go to the finish point as fast as you can!

## LEVEL & DIFFICULTIES

There are 5 levels in total & each new level increases the difficulty!

## INSTRUCTION

You have to use your **W,S,A,D** keys (_W - UP_, _S - DOWN_, _A - LEFT_, _D - RIGHT_) to navigate throught the maze!

### Made By: `Hamod Altaaf`

## About Game and Referrences

I have taken all needed code from the website referrenced below, customised it and added as many feature as i can!

## Referrences

- [Existing original game](https://html5.litten.com/make-a-maze-game-on-an-html5-canvas/)
- [Maze GIF Creator](http://hereandabove.com/maze/mazeorig.form.html)
- [Timer](https://stackoverflow.com/a/5517836)
